package UI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.mysql.jdbc.CallableStatement;
import com.mysql.jdbc.ResultSet;

import net.proteanit.sql.DbUtils;

import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.awt.event.ActionEvent;

public class Grid extends JFrame {

	private JPanel contentPane;
	private JTable table;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Grid frame = new Grid();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Grid() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 511, 325);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(80, 74, 344, 145);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JButton btnNewButton = new JButton("Load Data");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ObtenerDatos();
			}
		});
		btnNewButton.setBounds(164, 11, 89, 23);
		contentPane.add(btnNewButton);
	}
	
	public void ObtenerDatos()
	{
		try {
			Connection conn = getMySqlConnection();
			String simpleProc = "{ call TraerColegiosPorIdBarrio(?) }";			
		    CallableStatement cs = (CallableStatement) conn.prepareCall(simpleProc);
		    cs.setInt(1, 1);		   
		    ResultSet  rs = (ResultSet) cs.executeQuery();
		    table.setModel(DbUtils.resultSetToTableModel(rs));
		    
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	  public static Connection getMySqlConnection() throws Exception {
		    String driver = "com.mysql.jdbc.Driver";
		    String url = "jdbc:mysql://localhost/codoacodo";
		    String username = "root";
		    String password = "baufest";

		    Class.forName(driver);
		    Connection conn = (Connection) DriverManager.getConnection(url, username, password);
		    return conn;
	  }
}
